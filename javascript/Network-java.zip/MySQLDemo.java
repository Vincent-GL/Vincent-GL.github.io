package com.runoob.test;

import java.sql.*;

public class MySQLDemo {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/RUNOOB";

    static final String USER = "root";
    static final String PASS = "123456";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        try{
            // Register JDBC drive
            Class.forName(JDBC_DRIVER);

            // Open Connection
            System.out.println("Connect Database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            // Run Query
            System.out.println(" Instance Statement Object...");
            stmt = conn.createStatement();
            String sql;
            sql = "SELECT id, name, url FROM websites";
            ResultSet rs = stmt.executeQuery(sql);

            // show database
            while(rs.next()){
                // search
                int id  = rs.getInt("id");
                String name = rs.getString("name");
                String url = rs.getString("url");

                // output data
                System.out.print("ID: " + id);
                System.out.print(", Web name: " + name);
                System.out.print(", Web URL: " + url);
                System.out.print("\n");
            }

            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // process JDBC error
            se.printStackTrace();
        }catch(Exception e){
            // process Class.forName error
            e.printStackTrace();
        }finally{
            // release resource
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
}
